set sql_require_primary_key = off;
